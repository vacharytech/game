// ============================================================================
// GAME IMAGE CONFIGURATION
// ============================================================================
// This file makes it easy to replace game images with your own custom images
// Simply update the file paths below to point to your custom images

const GAME_IMAGES = {
    // ============================================================================
    // CAR IMAGES
    // ============================================================================
    
    // Your main car (the one you control)
    PLAYER_CAR: {
        path: 'assets/player-car.svg',
        width: 80,
        height: 120,
        description: 'Your main car that you control'
    },
    
    // Opponent cars (NPCs) - you can add multiple for variety
    NPC_CARS: {
        path: 'assets/npc-car.svg',
        width: 85,
        height: 125,
        description: 'Opponent cars with different colors and shapes'
    },
    
    // Additional NPC car types (SVG only)
    NPC_CAR_2: {
        path: 'assets/npc-car-2.svg',
        width: 85,
        height: 125,
        description: 'Second type of opponent car (SVG)'
    },
    
    NPC_CAR_3: {
        path: 'assets/!player-car.svg',
        width: 85,
        height: 125,
        description: 'Third type of opponent car (SVG)'
    },
    
    // ============================================================================
    // COLLECTIBLE IMAGES
    // ============================================================================
    
    // Coins to collect for points
    COIN: {
        path: 'assets/coin.svg',
        width: 25,
        height: 25,
        description: 'Items to collect for points'
    },
    
    // Powerups that give shields
    POWERUP: {
        path: 'assets/powerup.svg',
        width: 30,
        height: 30,
        description: 'Special items that give shields'
    },
    
    // ============================================================================
    // HAZARD IMAGES
    // ============================================================================
    
    // Blinking hazard lights
    HAZARD_LIGHT: {
        path: 'assets/hazard-light.svg',
        width: 30,
        height: 24,
        description: 'Blinking hazard lights'
    },
    
    // Road construction signs
    ROAD_WORK: {
        path: 'assets/road-work.svg',
        width: 30,
        height: 24,
        description: 'Road construction signs'
    },
    
    // Animal crossing signs
    CAMEL_CROSSING: {
        path: 'assets/camel-crossing.svg',
        width: 30,
        height: 24,
        description: 'Animal crossing signs'
    }
};

// ============================================================================
// QUICK REPLACEMENT GUIDE
// ============================================================================
/*
TO REPLACE IMAGES:

1. PLACE YOUR IMAGES:
   - Put your custom images in the 'assets' folder
   - Supported formats: .png, .jpg, .jpeg, .svg, .webp

2. UPDATE PATHS:
   - Change the 'path' values above to match your filenames
   - Example: 'assets/my-car.png'

3. ADJUST SIZES (optional):
   - Update 'width' and 'height' if your images are different sizes
   - The game will automatically scale images to these dimensions

4. TEST:
   - Refresh the game in your browser
   - Check console for loading messages
   - Your images should appear in the game

EXAMPLE REPLACEMENT:
-------------------
Original: path: 'assets/player-car.svg'
Your car: path: 'assets/my-red-sports-car.png'

Supported formats:
- PNG (.png) - Best for photos and complex graphics
- JPG (.jpg, .jpeg) - Good for photos, smaller file size
- SVG (.svg) - Best for simple graphics, scalable
- WebP (.webp) - Modern format, excellent compression
*/

// Export for use in the main game
if (typeof module !== 'undefined' && module.exports) {
    module.exports = GAME_IMAGES;
}
