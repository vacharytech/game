# 🎮 Game Assets - Image Replacement Guide

## 📁 How to Replace Game Images

### 🚗 **Car Images**

**Player Car:**
- **File**: `player-car.svg` (or your custom file)
- **Size**: 80×120 pixels recommended
- **Format**: PNG, JPG, SVG, or WebP
- **Description**: Your main car that you control

**NPC Cars (Opponents):**
- **File**: `npc-car.svg` (or your custom files)
- **Size**: 85×125 pixels recommended (various sizes work)
- **Format**: PNG, JPG, SVG, or WebP
- **Description**: Opponent cars with different colors and shapes

### 💰 **Collectible Images**

**Coins:**
- **File**: `coin.svg` (or your custom file)
- **Size**: 25×25 pixels recommended
- **Format**: PNG, JPG, SVG, or WebP
- **Description**: Items to collect for points

**Powerups:**
- **File**: `powerup.svg` (or your custom file)
- **Size**: 30×30 pixels recommended
- **Format**: PNG, JPG, SVG, or WebP
- **Description**: Special items that give shields

### ⚠️ **Hazard Images**

**Hazard Light:**
- **File**: `hazard-light.svg` (or your custom file)
- **Size**: 30×24 pixels recommended
- **Format**: PNG, JPG, SVG, or WebP
- **Description**: Blinking hazard lights

**Road Work:**
- **File**: `road-work.svg` (or your custom file)
- **Size**: 30×24 pixels recommended
- **Format**: PNG, JPG, SVG, or WebP
- **Description**: Road construction signs

**Camel Crossing:**
- **File**: `camel-crossing.svg` (or your custom file)
- **Size**: 30×24 pixels recommended
- **Format**: PNG, JPG, SVG, or WebP
- **Description**: Animal crossing signs

## 🔧 **Step-by-Step Replacement**

### 1. **Prepare Your Images**
```
assets/
├── player-car.png          ← Your main car
├── npc-car-1.png          ← Opponent car type 1
├── npc-car-2.png          ← Opponent car type 2
├── npc-car-3.png          ← Opponent car type 3
├── coin.png               ← Your coin design
├── powerup.png            ← Your powerup design
├── hazard-light.png       ← Your hazard light
├── road-work.png          ← Your road work sign
└── camel-crossing.png     ← Your crossing sign
```

### 2. **Update Image Paths**
Open `game.js` and find the `loadImages()` method. Update the paths:

```javascript
const imageList = {
    playerCar: 'assets/your-player-car.png',
    npcCar: 'assets/your-npc-car-1.png',
    npcCar2: 'assets/your-npc-car-2.png',
    npcCar3: 'assets/your-npc-car-3.png',
    coin: 'assets/your-coin.png',
    powerup: 'assets/your-powerup.png',
    hazardLight: 'assets/your-hazard-light.png',
    roadWork: 'assets/your-road-work.png',
    camelCrossing: 'assets/your-crossing.png'
};
```

### 3. **Test Your Images**
- Open the game in your browser
- Check the browser console (F12) for loading messages
- If images fail to load, fallback shapes will be used

## 🎨 **Design Tips**

### **Car Images:**
- **Transparent Background**: Use PNG with transparency
- **Consistent Style**: Keep all cars in similar art style
- **Clear Silhouette**: Make cars easily recognizable
- **Appropriate Sizes**: Don't make cars too large or small

### **Collectible Images:**
- **Bright Colors**: Make coins and powerups stand out
- **Simple Design**: Keep them recognizable at game speed
- **Consistent Theme**: Match your overall game aesthetic

### **Hazard Images:**
- **Warning Colors**: Use red, orange, or yellow
- **Clear Symbols**: Make hazards easily identifiable
- **Appropriate Size**: Not too large to block gameplay

## 🔄 **Multiple NPC Car Types**

To add variety to opponent cars, you can:

1. **Create multiple NPC car images**
2. **Update the NPC class** to randomly select from different images
3. **Add new image paths** to the `imageList`

Example:
```javascript
// In the NPC constructor, randomly select car image
const carImages = ['npc-car-1.png', 'npc-car-2.png', 'npc-car-3.png'];
const randomImage = carImages[Math.floor(Math.random() * carImages.length)];
this.carImage = this.images[randomImage];
```

## 🚀 **Quick Start**

1. **Replace one image at a time** to test
2. **Start with the player car** for immediate visual impact
3. **Use consistent naming** for your files
4. **Test on mobile** to ensure images work on all devices

## 📱 **Mobile Optimization**

- **Optimize file sizes** (under 50KB per image)
- **Use WebP format** for better compression
- **Test on different screen sizes**
- **Ensure images scale properly**

## 🎯 **Troubleshooting**

**Images not loading?**
- Check file paths are correct
- Ensure images are in the `assets` folder
- Verify file formats are supported
- Check browser console for errors

**Images too large/small?**
- Adjust the drawing code in `drawPlayer()` and `drawNPC()`
- Modify the `width` and `height` parameters
- Test different sizes until it looks right

**Performance issues?**
- Compress your images
- Use smaller file sizes
- Consider using WebP format
- Optimize image dimensions

---

**Need help?** Check the browser console for detailed loading information and error messages!
